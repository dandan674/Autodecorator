# AutoDecorator (Geode)

Proyecto fuente para compilar con Geode SDK / GitHub Actions. Incluye 50 paletas y botones de editor para selección, nivel completo y cambio de estilo.

## Qué intenta hacer esta versión
- `AD: SELECT`: recolorea los objetos seleccionados.
- `AD: ALL`: recolorea objetos compatibles y añade adornos de Glow (ID de objeto 914) y sierras (ID 88) usando el parser de objetos del editor. Los adornos están limitados para reducir el riesgo de saturar niveles grandes; las sierras se colocan en una banda superior.
- `AD: STYLE`: pasa al siguiente de los 50 estilos.

## Importante
Esta versión es experimental y **no está compilada ni probada dentro del juego**. Los IDs de objetos y el método de inserción deben verificarse en la versión de Geometry Dash/Geode de destino. Las sierras son objetos del juego y pueden afectar el gameplay si quedan demasiado cerca de la ruta; prueba una copia del nivel primero. La decoración del fondo visual y del suelo del juego no se puede modificar de forma fiable solo con recolorear objetos existentes; este prototipo añade adornos a la lista de objetos del nivel, no reconstruye los sprites internos del fondo/suelo.

## Compilar
Sube los archivos del proyecto al repositorio y ejecuta el workflow de GitHub Actions. Si falla, comparte el log de compilación para corregirlo.


### Decorative-only safety change (v1.1.1)
- Removed all sawblade (saw) insertion.
- The experimental full-level pass now attempts only the configured Glow decoration object and recolors compatible objects.
- This source has not been compiled or tested in-game; make a backup of your level before testing.
