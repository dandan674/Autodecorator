#include <Geode/Geode.hpp>
#include <Geode/modify/LevelEditorLayer.hpp>
#include <algorithm>
#include <vector>
using namespace geode::prelude;

namespace {
struct Style { const char* name; ccColor3B a; ccColor3B b; };
static Style const STYLES[] = {
    {"Glow", ccc3(0, 240, 255), ccc3(180, 80, 255)},
    {"Frutiger Aero", ccc3(0, 220, 190), ccc3(40, 150, 255)},
    {"Cyberpunk", ccc3(255, 30, 180), ccc3(0, 220, 255)},
    {"Vaporwave", ccc3(255, 100, 210), ccc3(100, 90, 255)},
    {"Synthwave", ccc3(255, 45, 120), ccc3(255, 160, 50)},
    {"Y2K Chrome", ccc3(210, 245, 255), ccc3(120, 160, 220)},
    {"Gótico", ccc3(150, 70, 230), ccc3(50, 30, 90)},
    {"Dark Fantasy", ccc3(180, 60, 220), ccc3(80, 30, 130)},
    {"Infernal", ccc3(255, 60, 20), ccc3(255, 170, 0)},
    {"Abismo", ccc3(20, 40, 110), ccc3(0, 190, 220)},
    {"Cementerio", ccc3(120, 150, 130), ccc3(80, 80, 110)},
    {"Dreamcore", ccc3(255, 180, 220), ccc3(160, 210, 255)},
    {"Weirdcore", ccc3(255, 230, 0), ccc3(255, 50, 120)},
    {"Liminal", ccc3(210, 220, 200), ccc3(130, 160, 170)},
    {"Backrooms", ccc3(190, 180, 90), ccc3(120, 115, 60)},
    {"Glitchcore", ccc3(255, 0, 100), ccc3(0, 255, 230)},
    {"Neo-Tokyo", ccc3(255, 50, 150), ccc3(40, 170, 255)},
    {"Anime Cel-Shading", ccc3(255, 120, 170), ccc3(80, 190, 255)},
    {"Vocaloid / Miku", ccc3(55, 245, 205), ccc3(255, 110, 190)},
    {"Manga", ccc3(245, 245, 245), ccc3(30, 30, 30)},
    {"Arcade 1980", ccc3(0, 255, 90), ccc3(255, 30, 80)},
    {"Bioluminiscente", ccc3(80, 255, 170), ccc3(130, 80, 255)},
    {"Alienígena", ccc3(150, 255, 40), ccc3(150, 50, 230)},
    {"Océano profundo", ccc3(0, 120, 190), ccc3(50, 240, 230)},
    {"Cristal", ccc3(190, 245, 255), ccc3(95, 160, 255)},
    {"Hielo ártico", ccc3(170, 240, 255), ccc3(220, 250, 255)},
    {"Steampunk", ccc3(220, 150, 50), ccc3(120, 75, 35)},
    {"Dieselpunk", ccc3(180, 150, 110), ccc3(70, 80, 85)},
    {"Retrofuturismo", ccc3(255, 190, 70), ccc3(80, 210, 230)},
    {"Laboratorio Sci-Fi", ccc3(0, 255, 220), ccc3(80, 120, 255)},
    {"Nanotecnología", ccc3(70, 255, 220), ccc3(120, 80, 255)},
    {"Bosque encantado", ccc3(80, 230, 120), ccc3(180, 255, 100)},
    {"Naturaleza otoñal", ccc3(230, 100, 35), ccc3(255, 190, 60)},
    {"Desierto antiguo", ccc3(230, 180, 100), ccc3(180, 90, 45)},
    {"Civilización maya", ccc3(30, 210, 130), ccc3(230, 170, 50)},
    {"Jardín japonés", ccc3(255, 150, 190), ccc3(100, 200, 170)},
    {"Brutalismo", ccc3(170, 170, 170), ccc3(80, 90, 100)},
    {"Minimalista", ccc3(240, 240, 240), ccc3(100, 170, 200)},
    {"Abstracto", ccc3(255, 80, 150), ccc3(100, 90, 255)},
    {"Origami", ccc3(255, 235, 180), ccc3(80, 170, 190)},
    {"Low Poly", ccc3(100, 220, 160), ccc3(255, 150, 80)},
    {"Op Art", ccc3(245, 245, 245), ccc3(30, 30, 30)},
    {"Monocromático", ccc3(235, 235, 235), ccc3(100, 100, 100)},
    {"Tinta y papel", ccc3(235, 220, 190), ccc3(50, 45, 40)},
    {"Vitral", ccc3(255, 90, 120), ccc3(70, 180, 255)},
    {"Holográfico", ccc3(80, 255, 245), ccc3(255, 80, 220)},
    {"Líquido", ccc3(80, 210, 255), ccc3(180, 100, 255)},
    {"Explosión cósmica", ccc3(130, 80, 255), ccc3(255, 80, 150)},
    {"Caos fractal", ccc3(80, 255, 100), ccc3(255, 50, 150)},
    {"Fusión de dimensiones", ccc3(0, 240, 255), ccc3(255, 50, 200)}
};
static constexpr unsigned int STYLE_COUNT = sizeof(STYLES) / sizeof(STYLES[0]);
static unsigned int g_style = 0;

ccColor3B styleColor(unsigned int index) {
    auto const& s = STYLES[g_style % STYLE_COUNT];
    return (index % 2 == 0) ? s.a : s.b;
}
void recolor(GameObject* object, unsigned int index) {
    if (!object) return;
    object->setObjectColor(styleColor(index));
}
CCMenuItemSpriteExtra* makeButton(const char* text, CCObject* target, SEL_MenuHandler selector) {
    auto label = CCLabelBMFont::create(text, "bigFont.fnt");
    if (!label) return nullptr;
    label->setScale(0.42f);
    auto item = CCMenuItemSpriteExtra::create(label, target, selector);
    if (item) item->setScale(0.85f);
    return item;
}
}

class $modify(AutoDecoratorEditor, LevelEditorLayer) {
    bool init(GJGameLevel* level, bool noUI) {
        if (!LevelEditorLayer::init(level, noUI)) return false;
        auto menu = CCMenu::create();
        if (!menu) return true;
        menu->setID("autodecorator-menu"_spr);
        menu->setPosition({95.f, 65.f});
        menu->setContentSize({180.f, 70.f});
        menu->setLayout(RowLayout::create()->setGap(7.f)->setAxisAlignment(AxisAlignment::Start));
        if (auto b = makeButton("AD: SELECT", this, menu_selector(AutoDecoratorEditor::onDecorateSelected))) {
            b->setID("autodecorator-selected"_spr); menu->addChild(b);
        }
        if (auto b = makeButton("AD: ALL", this, menu_selector(AutoDecoratorEditor::onDecorateAll))) {
            b->setID("autodecorator-all"_spr); menu->addChild(b);
        }
        if (auto b = makeButton("AD: STYLE", this, menu_selector(AutoDecoratorEditor::onNextStyle))) {
            b->setID("autodecorator-style"_spr); menu->addChild(b);
        }
        menu->updateLayout();
        this->addChild(menu, 1000);
        return true;
    }
    void onDecorateSelected(CCObject*) {
        auto selected = this->m_selectedObjects;
        if (!selected || selected->count() == 0) {
            FLAlertLayer::create("AutoDecorator", "Select one or more objects first.", "OK")->show(); return;
        }
        unsigned int count = 0;
        for (unsigned int i = 0; i < selected->count(); ++i) {
            auto object = typeinfo_cast<GameObject*>(selected->objectAtIndex(i));
            if (object) recolor(object, count++);
        }
        FLAlertLayer::create("AutoDecorator", fmt::format("Style '{}': recolored {} selected objects.", STYLES[g_style].name, count), "OK")->show();
    }
    // Adds saved Geometry Dash level objects through the editor's object-string parser.
    // Decorative-only pass: use the configured glow detail object; never insert sawblades.
    unsigned int addDecorationAt(float x, float y, int objectID, ccColor3B color) {
        auto objectString = fmt::format("1,{},2,{:.2f},3,{:.2f},21,3,22,3,24,1;", objectID, x, y);
        this->addObjectFromString(objectString);
        auto objects = this->m_objects;
        if (objects && objects->count() > 0) {
            auto obj = typeinfo_cast<GameObject*>(objects->objectAtIndex(objects->count() - 1));
            if (obj) {
                obj->setObjectColor(color);
                obj->setScale(0.65f);
            }
        }
        return 1;
    }

    void onDecorateAll(CCObject*) {
        auto objects = this->m_objects;
        if (!objects || objects->count() == 0) {
            FLAlertLayer::create("AutoDecorator", "No editor objects found.", "OK")->show(); return;
        }
        // Snapshot the source objects before adding anything, so generated decorations
        // are never processed again in this pass. Hard cap keeps huge levels responsive.
        std::vector<CCPoint> points;
        points.reserve(std::min<unsigned int>(objects->count(), 5000));
        for (unsigned int i = 0; i < objects->count() && i < 5000; ++i) {
            auto object = typeinfo_cast<GameObject*>(objects->objectAtIndex(i));
            if (!object) continue;
            // Preserve gameplay objects; recolor only ordinary block/deco candidates.
            if (!object->m_isTrigger && object->m_objectID != 12 && object->m_objectID != 13 &&
                object->m_objectID != 35 && object->m_objectID != 36 && object->m_objectID != 39 &&
                object->m_objectID != 55 && object->m_objectID != 56 && object->m_objectID != 57 &&
                object->m_objectID != 1913 && object->m_objectID != 1934) {
                recolor(object, i);
                points.push_back(object->getPosition());
            }
        }
        unsigned int added = 0;
        // Add glow details near existing objects, with a strict limit to avoid bloating.
        auto limit = std::min<size_t>(points.size(), 500);
        for (size_t i = 0; i < limit; ++i) {
            auto p = points[i];
            added += addDecorationAt(p.x + ((i % 2) ? 18.f : -18.f), p.y + 22.f, 914, styleColor((unsigned)i));
        }
        FLAlertLayer::create("AutoDecorator", fmt::format("Modo '{}': se añadieron hasta {} adornos decorativos Glow (sin sierras) y se recolorearon objetos compatibles. Revisa el nivel y prueba el gameplay antes de guardar.", STYLES[g_style].name, added), "OK")->show();
    }
    void onNextStyle(CCObject*) {
        g_style = (g_style + 1) % STYLE_COUNT;
        FLAlertLayer::create("AutoDecorator", fmt::format("Estilo {}/{}: {}. Usa SELECT o ALL para aplicar el estilo.", g_style + 1, STYLE_COUNT, STYLES[g_style].name), "OK")->show();
    }
};
